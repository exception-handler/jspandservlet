package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


public class Registation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter outGet = response.getWriter();
		outGet.println("hello");
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
			String userName=request.getParameter("username");
			String password=request.getParameter("password");
		
			response.setContentType("text/html");
			try {
				
				DataBase obj = new DataBase();
				boolean b = obj.validateUser(userName, password);
				
				if(b) out.print("<h1>WELCOME</h1>"+userName);
				else  out.print("<h1>UNAUTHORISED USER</h1>");
				
			} catch (Exception e) {
				out.print(e);
			}
			
			
		
		
		
		
	}

	

}
