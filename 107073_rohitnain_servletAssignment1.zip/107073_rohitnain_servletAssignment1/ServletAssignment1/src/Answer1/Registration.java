package Answer1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out=response.getWriter();
		String firstName=request.getParameter("fistname");	
		String lastName=request.getParameter("lastname");
		String loginName=request.getParameter("loginname");
		int age=Integer.parseInt(request.getParameter("age"));
		String checkBox=request.getParameter("check");
		out.println("First name is:"+firstName+"<br>");
		out.println("Last name is:"+lastName+"<br>");
		out.println("Login name is:"+loginName+"<br>");
		out.println("Age is:"+age+"<br>");
		out.println("Topic is:"+checkBox);
	}



}
