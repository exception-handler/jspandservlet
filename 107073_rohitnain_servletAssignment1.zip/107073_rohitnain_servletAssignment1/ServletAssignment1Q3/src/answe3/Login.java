package answe3;

import java.io.IOException;
import java.util.ArrayList;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.xml.internal.bind.v2.schemagen.xmlschema.List;

import jdk.nashorn.internal.ir.RuntimeNode.Request;

public class Login extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
 
	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		java.util.List<User> list=new ArrayList<>();
		
		list.add(new User("Rohit", "123"));
		list.add(new User("Mohit", "456"));
		
	
		String loginName=request.getParameter("loginname");

		String password=request.getParameter("password");
		String page="";
		for (User user : list) {
			
		if (user.getUserName().equals(loginName) && user.getPassword().equals(password)) {
			
			request.setAttribute("user", loginName);
			
			request.setAttribute("pass", password);
			page="DisplayData";
			break;
	
	} else {
		page="index.html";
		
	}
		
		}
		RequestDispatcher rd = request.getRequestDispatcher(page);
		rd.forward(request, response);
		
	}

	
	
	
}

