package answer2;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		String firstName = request.getParameter("fistname");
		String lastName = request.getParameter("lastname");
		String loginName = request.getParameter("loginname");
		int age = Integer.parseInt(request.getParameter("age"));
		String topic[] = request.getParameterValues("check");
              boolean cond =firstName.isEmpty();
              boolean cond1 =lastName.isEmpty();
              boolean cond2 =loginName.isEmpty();
		if(cond==false && cond1==false && cond2==false && age!=0)
		{
			out.println("Object created");
			User user=new User(firstName, lastName, loginName, age, topic);
			out.println(user);
		}
		else
		{
			out.println("Object not created");
		}

	}

}
