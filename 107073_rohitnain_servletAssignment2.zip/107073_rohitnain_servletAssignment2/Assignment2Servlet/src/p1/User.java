package p1;

import java.util.Arrays;

public class User {
	private String firstName;
	private String lastName;
	private String loginName;
	private int age;
	private String[] topic;
	
	
	public String getFirstName() {
		return firstName;
	}
	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}
	public String getLastName() {
		return lastName;
	}
	public void setLastName(String lastName) {
		this.lastName = lastName;
	}
	public String getLoginName() {
		return loginName;
	}
	public void setLoginName(String loginName) {
		this.loginName = loginName;
	}
	public int getAge() {
		return age;
	}
	public void setAge(int age) {
		this.age = age;
	}
	public String[] getTopic() {
		return topic;
	}
	public void setTopic(String[] topic) {
		this.topic = topic;
	}
	public User(String firstName, String lastName, String loginName, int age, String[] topic) {
		super();
		this.firstName = firstName;
		this.lastName = lastName;
		this.loginName = loginName;
		this.age = age;
		this.topic = topic;
	}
	@Override
	public String toString() {
		return "User [firstName=" + firstName + ", lastName=" + lastName + ", loginName=" + loginName + ", age=" + age
				+ ", topic=" + Arrays.toString(topic) + "]";
	}
}
