package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 * Servlet implementation class TopicHyperLink
 */
public class TopicHyperLink extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con;
		PreparedStatement ps;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		HttpSession session = request.getSession(false);
		String sessionID = (String) session.getAttribute("sessionID");
		out.println("<br/> session id is" + sessionID + "<hr/>");
		out.println("<a href='LogOut'>Logout</a>"+"<br>");
		
		
		String loginName=request.getParameter("loginname");
	
		try{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/myTestDBCP");
		con = ds.getConnection();
		ps = con.prepareStatement("select topic from servlet where loginname=?");
		ps.setString(1, loginName);
		ResultSet rs = ps.executeQuery();
	
		while(rs.next())
		{
			out.println("<a href='#'>"+rs.getString(1)+"</a>");
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
	}

	
}
