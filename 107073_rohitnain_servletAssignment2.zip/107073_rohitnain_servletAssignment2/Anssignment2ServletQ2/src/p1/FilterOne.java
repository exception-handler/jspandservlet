package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Date;

import javax.servlet.Filter;
import javax.servlet.FilterChain;
import javax.servlet.FilterConfig;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.http.HttpServletRequest;


public class FilterOne implements Filter {

   
    public FilterOne() {
      
    }

	public void destroy() {
		
	}

	
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		
		chain.doFilter(request, response);
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		Date date=new Date();
		out.println("<hr/>");
		out.println(date);
	}

	
	public void init(FilterConfig fConfig) throws ServletException {
		
	}

}
