package p1;

public class User {
String firstname;
String lastname;
String loginname;
int age;
String topic;
public User() {
	super();
	// TODO Auto-generated constructor stub
}
public User(String firstname, String lastname, String loginname, int age, String topic) {
	super();
	this.firstname = firstname;
	this.lastname = lastname;
	this.loginname = loginname;
	this.age = age;
	this.topic = topic;
}
public String getFirstname() {
	return firstname;
}
public void setFirstname(String firstname) {
	this.firstname = firstname;
}
public String getLastname() {
	return lastname;
}
public void setLastname(String lastname) {
	this.lastname = lastname;
}
public String getLoginname() {
	return loginname;
}
public void setLoginname(String loginname) {
	this.loginname = loginname;
}
public int getAge() {
	return age;
}
public void setAge(int age) {
	this.age = age;
}
public String getTopic() {
	return topic;
}
public void setTopic(String topic) {
	this.topic = topic;
}
@Override
public String toString() {
	return "User [firstname=" + firstname + ", lastname=" + lastname + ", loginname=" + loginname + ", age=" + age
			+ ", topic=" + topic + "]";
}

}
