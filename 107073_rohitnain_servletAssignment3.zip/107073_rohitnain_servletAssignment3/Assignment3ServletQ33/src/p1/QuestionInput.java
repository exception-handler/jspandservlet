package p1;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/QuestionInput")
public class QuestionInput extends HttpServlet {
	private static final long serialVersionUID = 1L;

	public QuestionInput() {
		super();

	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		response.setContentType("text/html");
		PrintWriter out= response.getWriter();
		HttpSession session=request.getSession(false);
		if(session==null)
		{
			response.sendRedirect("index.html");
		}
		else
		{
			String Topic=request.getParameter("topic");
			out.println("<h1>"+Topic+"</h1>");
			out.println("<br>");
		out.print("<html><body>");
		out.print("<form method='get' action='QuestionAndAnswer'>");
		out.print("<input type='text' placeholder='Enter your question' name='question' >");
		out.print("<input type='text' placeholder='Enter Your answer' name='answer' >");
		out.print("<input type='hidden'  name='topic' value='"+Topic+"'>");
		out.print("<input type='submit' name='button' value='Submit' >");
		out.print("<input type='submit' name='button' value='Enter More' >");
		out.print("<input type='submit' name='button' value='Back' >");
		out.print("</form>");
		out.print("</html></body>");
		}
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

	}

}
