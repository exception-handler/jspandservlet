package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.SQLException;

import javax.naming.NamingException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.sun.corba.se.spi.activation.Repository;

/**
 * Servlet implementation class QuestionAndAnswer
 */
public class QuestionAndAnswer extends HttpServlet {
	private static final long serialVersionUID = 1L;

	int id = 100;

	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		out.println("<h1>WELCOME TO TOPIC CONTROLLER</h1>");

		String button = request.getParameter("button");

		String topicName = request.getParameter("topic");
		out.println(topicName);

		String question = request.getParameter("question");

		String answer = request.getParameter("answer");
		if (button.equals("Submit")) {
			id++;
			try {
				DataBaseOperation db = new DataBaseOperation();
				if (db.insertquestion(question, answer, topicName, id)) {
					out.print("Question Saved..  Go To<a href='TopicHyperLink'>Topic List</a>");
				}

			} catch (SQLException | NamingException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		} else if (button.equals("Enter More")) {
			DataBaseOperation db;
			try {
				db = new DataBaseOperation();
				
				if (db.insertquestion(question, answer, topicName, id)) {
					response.sendRedirect("QuestionInput?topic="+topicName);
				}
			} catch (Exception e) {
				// TODO Auto-generated catch block
				e.printStackTrace();

			}

		} else {
			System.out.println("asddasasdasdsadsda");
			response.sendRedirect("TopicHyperLink");
		}
	}

}
