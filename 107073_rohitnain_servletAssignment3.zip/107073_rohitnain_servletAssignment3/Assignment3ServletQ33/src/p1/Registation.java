package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.Random;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;


public class Registation extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
  




	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
			String button=request.getParameter("submit");
			
			if(button.equals("login"))
			{
			String loginName=request.getParameter("loginname");
			String password=request.getParameter("password");
		
			response.setContentType("text/html");
			try {
				
				DataBase obj = new DataBase();
				boolean b = obj.validateUser(loginName, password);
				
				if(b) 
					{
					HttpSession session =request.getSession(true);
					session.setAttribute("sessionID", session.getId());
					request.setAttribute("loginname", loginName);
					session.setAttribute("loginname", loginName);
					RequestDispatcher rd = request.getRequestDispatcher("UserInfo");
					rd.forward(request, response);
					}
				else  
				{
					RequestDispatcher rd = request.getRequestDispatcher("Error");
					rd.forward(request, response);
					/*out.println("HELLO");*/
				}
				
			} catch (Exception e) {
				out.print(e);
			}
			
			
			}//if end
		
			else if(button.equals("register"))
			{
				String firstName = request.getParameter("fistname");
				String lastName = request.getParameter("lastname");
				String loginName = request.getParameter("loginname");
				int age;
				
				String age1=request.getParameter("age");
				if(age1=="")
				{
					age=0;
				}
				else
				{
					age = Integer.parseInt(request.getParameter("age"));
				}
				
				String topic[] = request.getParameterValues("check");
		              boolean cond =firstName.isEmpty();
		              boolean cond1 =lastName.isEmpty();
		              boolean cond2 =loginName.isEmpty();
				if(cond==false && cond1==false && cond2==false && age!=0 && topic.length!=0)
				{
					Random random=new Random();
					
					int pass=(int)(Math.random()*100);
					String password=loginName+pass;
					String str="";
					for (String string : topic) {
						str=str+string+"<br>";
					}
							
					try {
						DataBaseOperation obj = new DataBaseOperation();
						boolean b = obj.insertUser(firstName, lastName, loginName, password, age, str);
						
						if(b) {
							//out.print("Data Inserted<br>");
							out.println("Your password is:"+password);
							out.println("<a href='index.html'>LOGIN</a>");
						}
						else  out.print("Data Not Inserted");
						
					} catch (Exception e) {
						out.print(e);
					}
				}
				else
				{
					out.println("PLEASE ENTER FEILDS");
				}
			}
		
	}//function end

	

}//class end
