package p1;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;
import javax.sql.DataSource;

/**
 * Servlet implementation class UserInfo
 */
public class UserInfo extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Connection con;
		PreparedStatement ps;
		response.setContentType("text/html");
		PrintWriter out = response.getWriter();
		
		
		HttpSession session = request.getSession(false);
		String sessionID = (String) session.getAttribute("sessionID");
		out.println("<br/> session id is" + sessionID + "<hr/>");
		out.println("<a href='LogOut'>Logout</a>"+"<br>");
		
		
		String loginName=(String) request.getAttribute("loginname");
		try{
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/myTestDBCP");
		con = ds.getConnection();
		ps = con.prepareStatement("select * from servlet where loginname=?");
		ps.setString(1, loginName);
		ResultSet rs = ps.executeQuery();
		while(rs.next())
		{
			out.println("First name is : "+rs.getString(1)+"<br>");
			out.println("last name is : "+rs.getString(2)+"<br>");
			out.println("login name is : "+rs.getString(3)+"<br>");
			out.println("password is : "+rs.getString(4)+"<br>");
			out.println("age is : "+rs.getInt(5)+"<br>");
			out.println("topics are : "+rs.getString(6)+"<br>");
			
		}
		
		}
		catch(Exception e)
		{
			e.printStackTrace();
		}
		
		out.print("<h1>WELCOME</h1>"+loginName);
		out.println("<a href='UpdateInfo'>CLICK TO UPDATE DETAILS</a>");
		out.println("<br>Go to ");
		out.println("<a href='TopicHyperLink?loginname="+loginName+"'>Topic List Page</a>"+"<br>");
		/*request.setAttribute("loginname", loginName);
		RequestDispatcher rd = request.getRequestDispatcher("TopicHyperLink");
		rd.forward(request, response);*/
		
	}

}
