package p1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DataBaseOperation {
	Connection con;
	PreparedStatement ps;
	
	
		
	
	
	public DataBaseOperation() throws NamingException, SQLException {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/myTestDBCP");
		con = ds.getConnection();
		System.out.println(" ->. con " + con);
	}





	public boolean insertUser(String firstname,String lastname,String loginname,String password,int age,String topic)throws Exception
	{
		boolean isInserted = false;
		
		ps = con.prepareStatement("insert into servlet values(?,?,?,?,?,?)");
		ps.setString(1,firstname);
		ps.setString(2,lastname);
		ps.setString(3,loginname);
		ps.setString(4,password);
		ps.setInt(5,age);
		ps.setString(6,topic);
		int x = ps.executeUpdate();
		if(x>0)isInserted = true;
		return isInserted;
	}
}
