package p1;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

import javax.naming.Context;
import javax.naming.InitialContext;
import javax.naming.NamingException;
import javax.sql.DataSource;

public class DataBase {
	Connection con;
	PreparedStatement ps;

	public DataBase() throws SQLException, NamingException {
		Context ctx = new InitialContext();
		DataSource ds = (DataSource) ctx.lookup("java:comp/env/jdbc/myTestDBCP");
		con = ds.getConnection();
		System.out.println("database");
	}
	
	public boolean validateUser(String loginname,String password)throws Exception
	{
		System.out.println("in validate");
		boolean isValid = false;
		System.out.println(getClass()+" -------->> Validate User called ...."+loginname+" & "+password);
		ps = con.prepareStatement("select * from servlet where LOGINNAME = ? and PASSWORD = ?");
		ps.setString(1,loginname);
		ps.setString(2,password);
		ResultSet rs = ps.executeQuery();
		System.out.println(rs);
		while(rs.next())
		{
			System.out.println(isValid);
			isValid = true;
			System.out.println(isValid);
		}
		System.out.println(getClass()+" -------->> Validate User return  ...."+isValid);
		return isValid;
	}
}
